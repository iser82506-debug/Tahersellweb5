# TAHER DEV MARKET
`npm install && npm run dev`
- Admin demo login: admin@taher.dev / admin123 → /#/admin
- Prices live in product data (edit in /admin). Seed prices in src/lib/data.ts are placeholders.
- Swap mock payment: src/services/payment.ts. Swap localStorage store for Supabase: src/lib/store.tsx.
