import {Link,Navigate} from 'react-router-dom'
import {useStore} from '../lib/store'
import {taka,date,download} from '../utils/format'
const mine=(s:any)=>s.orders.filter((o:any)=>o.email===s.user?.email)
export function Account(){
  const s=useStore();const {user,logout}=s
  if(!user)return <Navigate to="/login"/>
  const bought=mine(s).flatMap((o:any)=>o.items.map((i:any)=>({...i,oid:o.id})))
  return <div className="max-w-4xl mx-auto px-4 py-12 space-y-8"><div className="glass p-6 flex items-center justify-between"><div><h1 className="h1 text-3xl">{user.name}</h1><p className="text-white/50">{user.email}</p></div><div className="flex gap-2"><Link to="/account/orders" className="btn btn-g">My Orders</Link><button onClick={logout} className="btn btn-g">Logout</button></div></div>
    <section><h2 className="h1 text-2xl mb-4">Purchased products</h2>{!bought.length&&<p className="text-white/50">Nothing purchased yet.</p>}<div className="space-y-3">{bought.map((i:any)=><div key={i.licenseKey} className="glass p-5 flex flex-wrap items-center justify-between gap-3"><div><b>{i.name}</b><div className="text-xs text-white/50 mt-1">License: <code className="text-gold">{i.licenseKey}</code></div></div><button className="btn btn-p" onClick={()=>download(i.name,i.licenseKey)}>Download</button></div>)}</div></section></div>
}
export function MyOrders(){
  const s=useStore()
  if(!s.user)return <Navigate to="/login"/>
  const os=mine(s)
  return <div className="max-w-4xl mx-auto px-4 py-12"><h1 className="h1 text-4xl mb-8">My Orders</h1>{!os.length&&<p className="text-white/50">No orders yet.</p>}<div className="space-y-3">{os.map((o:any)=><Link key={o.id} to={`/order/${o.id}`} className="glass lift p-5 flex justify-between items-center"><div><b>{o.id}</b><div className="text-xs text-white/50">{date(o.createdAt)} · {o.items.length} item(s)</div></div><div className="text-right"><b className="text-gold">{taka(o.total)}</b><div className="text-xs text-emerald-300">{o.status}</div></div></Link>)}</div></div>
}
