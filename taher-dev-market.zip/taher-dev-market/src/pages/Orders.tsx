import {useState} from 'react'
import {Link,useNavigate,useParams,useSearchParams} from 'react-router-dom'
import {useStore} from '../lib/store'
import {Cover} from '../components/ProductCard'
import {effective,taka,date,licenseKey,orderId,download} from '../utils/format'
import {pay} from '../services/payment'
export function Cart(){
  const {cart,products,removeFromCart}=useStore();const items=cart.map((id:string)=>products.find((p:any)=>p.id===id)).filter(Boolean)
  const total=items.reduce((s:number,p:any)=>s+effective(p),0)
  if(!items.length)return <div className="max-w-3xl mx-auto px-4 py-24 text-center"><h1 className="h1 text-4xl">Your cart is empty</h1><Link to="/products" className="btn btn-p mt-8">Browse Products</Link></div>
  return <div className="max-w-4xl mx-auto px-4 py-12"><h1 className="h1 text-4xl mb-8">Cart</h1><div className="space-y-3">{items.map((p:any)=><div key={p.id} className="glass p-3 flex items-center gap-4"><Cover p={p} className="w-20 h-16 rounded-xl"/><div className="flex-1"><b>{p.name}</b><div className="text-xs text-white/45">{p.category}</div></div><b className="text-gold">{taka(effective(p))}</b><button className="text-white/40 hover:text-red-400 px-2" onClick={()=>removeFromCart(p.id)}>✕</button></div>)}</div>
    <div className="glass p-6 mt-6 flex items-center justify-between"><div><div className="text-white/50 text-sm">Total</div><div className="text-2xl font-bold text-gold">{taka(total)}</div></div><Link to="/checkout" className="btn btn-p">Checkout</Link></div></div>
}
export function Checkout(){
  const {cart,products,user,setUser,clearCart,addOrder}=useStore();const [sp]=useSearchParams();const nav=useNavigate();const buy=sp.get('buy')
  const ids=buy?[buy]:cart;const items=ids.map((id:string)=>products.find((p:any)=>p.id===id)).filter(Boolean);const total=items.reduce((s:number,p:any)=>s+effective(p),0)
  const [f,setF]=useState({name:user?.name||'',email:user?.email||'',phone:'',method:'Mock Payment (bKash/Card)'});const [busy,setBusy]=useState(false)
  if(!items.length)return <div className="max-w-3xl mx-auto px-4 py-24 text-center"><h1 className="h1 text-3xl">Nothing to check out</h1><Link to="/products" className="btn btn-p mt-6">Browse</Link></div>
  const submit=async(e:any)=>{e.preventDefault();setBusy(true);const r=await pay(total,f.method)
    if(!r.ok){setBusy(false);return alert('Payment failed')}
    const o={id:orderId(),email:f.email,name:f.name,items:items.map((p:any)=>({id:p.id,name:p.name,price:effective(p),licenseKey:licenseKey()})),total,status:'completed',payment:'paid',method:f.method,createdAt:Date.now()}
    addOrder(o);setUser({name:f.name,email:f.email});if(!buy)clearCart();nav('/order/'+o.id)}
  return <form onSubmit={submit} className="max-w-5xl mx-auto px-4 py-12 grid md:grid-cols-5 gap-8"><div className="md:col-span-3 glass p-6 space-y-4"><h1 className="h1 text-3xl">Checkout</h1>
    <input required className="input" placeholder="Full name" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/><input required type="email" className="input" placeholder="Email" value={f.email} onChange={e=>setF({...f,email:e.target.value})}/><input className="input" placeholder="Phone" value={f.phone} onChange={e=>setF({...f,phone:e.target.value})}/>
    <select className="input" value={f.method} onChange={e=>setF({...f,method:e.target.value})}><option>Mock Payment (bKash/Card)</option></select><p className="text-xs text-white/40">Demo mode: payment always succeeds. No real charge.</p></div>
    <div className="md:col-span-2 glass p-6 h-fit space-y-3"><h2 className="font-semibold">Summary</h2>{items.map((p:any)=><div key={p.id} className="flex justify-between text-sm text-white/70"><span>{p.name}</span><span>{taka(effective(p))}</span></div>)}<div className="border-t border-white/10 pt-3 flex justify-between font-bold"><span>Total</span><span className="text-gold">{taka(total)}</span></div><button disabled={busy} className="btn btn-p w-full">{busy?'Processing…':`Pay ${taka(total)}`}</button></div></form>
}
export function OrderPage(){
  const {id}=useParams();const {orders}=useStore();const o=orders.find((x:any)=>x.id===id)
  if(!o)return <p className="p-12 text-center">Order not found.</p>
  return <div className="max-w-3xl mx-auto px-4 py-12"><div className="text-center mb-8"><div className="text-5xl">✅</div><h1 className="h1 text-4xl mt-3">Order confirmed</h1><p className="text-white/50 mt-2">Order <b className="text-white">{o.id}</b> · {date(o.createdAt)}</p><span className="inline-block mt-3 text-xs px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300">Payment {o.payment} · {o.status}</span></div>
    <div className="space-y-3">{o.items.map((i:any)=><div key={i.id} className="glass p-5 flex flex-wrap items-center gap-4 justify-between"><div><b>{i.name}</b><div className="text-xs text-white/50 mt-1">License: <code className="text-gold">{i.licenseKey}</code></div></div><button className="btn btn-p" onClick={()=>download(i.name,i.licenseKey)}>Download</button></div>)}</div>
    <div className="glass p-5 mt-4 flex justify-between"><span>Total paid</span><b className="text-gold">{taka(o.total)}</b></div><div className="text-center mt-6"><Link to="/account/orders" className="btn btn-g">My Orders</Link></div></div>
}
