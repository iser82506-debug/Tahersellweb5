import {Link,useNavigate,useParams,useSearchParams} from 'react-router-dom'
import {useStore} from '../lib/store'
import ProductCard,{Cover,Price} from '../components/ProductCard'
export function Products(){
  const {products,categories}=useStore();const [sp,setSp]=useSearchParams();const q=sp.get('q')||'',cat=sp.get('cat')||''
  const set=(k:string,v:string)=>{const n=new URLSearchParams(sp);v?n.set(k,v):n.delete(k);setSp(n)}
  const res=products.filter((p:any)=>(!cat||p.category===cat)&&(p.name+p.short+p.tech.join(' ')).toLowerCase().includes(q.toLowerCase()))
  return <div className="max-w-6xl mx-auto px-4 py-12"><h1 className="h1 text-4xl md:text-5xl">All Products</h1>
    <input className="input mt-6" placeholder="Search products, technologies…" value={q} onChange={e=>set('q',e.target.value)}/>
    <div className="flex flex-wrap gap-2 mt-4">{['',...categories].map((c:string)=><button key={c} onClick={()=>set('cat',c)} className={`btn !py-1.5 ${cat===c?'btn-p':'btn-g'}`}>{c||'All'}</button>)}</div>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-8">{res.map((p:any)=><ProductCard key={p.id} p={p}/>)}</div>
    {!res.length&&<p className="text-white/50 mt-10">No products found.</p>}</div>
}
export function Categories(){
  const {products,categories}=useStore()
  return <div className="max-w-6xl mx-auto px-4 py-12"><h1 className="h1 text-4xl md:text-5xl">Categories</h1><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-8">{categories.map((c:string)=><Link key={c} to={`/products?cat=${encodeURIComponent(c)}`} className="glass lift p-8"><b className="text-xl">{c}</b><p className="text-sm text-white/45 mt-2">{products.filter((p:any)=>p.category===c).length} products</p></Link>)}</div></div>
}
export function ProductDetails(){
  const {id}=useParams();const {products,addToCart}=useStore();const nav=useNavigate();const p=products.find((x:any)=>x.id===id)
  if(!p)return <p className="max-w-6xl mx-auto p-12">Product not found. <Link to="/products" className="text-violet-300">Back</Link></p>
  const L=({t,a}:{t:string;a:string[]})=><div><h3 className="font-semibold mb-3">{t}</h3><ul className="space-y-1.5 text-sm text-white/65">{a.map(x=><li key={x}>✓ {x}</li>)}</ul></div>
  return <div className="max-w-6xl mx-auto px-4 py-12 grid lg:grid-cols-5 gap-8">
    <div className="lg:col-span-3 space-y-4"><div className="glass p-2"><Cover p={p} className="w-full h-72 md:h-96 rounded-2xl"/></div>
      {p.images.length>1&&<div className="flex gap-3 overflow-x-auto">{p.images.slice(1).map((s:string)=><img key={s} src={s} className="h-20 rounded-xl"/>)}</div>}
      <div className="glass p-6 md:p-8 space-y-6"><p className="text-white/70 leading-relaxed">{p.description}</p><div className="grid sm:grid-cols-2 gap-6"><L t="Features" a={p.features}/><L t="What's included" a={p.included}/></div></div></div>
    <aside className="lg:col-span-2"><div className="glass p-6 md:p-8 lg:sticky lg:top-24 space-y-5">
      <span className="text-violet-300 text-sm">{p.category}</span><h1 className="h1 text-3xl">{p.name}</h1><p className="text-white/55">{p.short}</p>
      <div className="text-2xl"><Price p={p}/></div>
      <div className="flex gap-3"><button disabled={!p.available} className="btn btn-p flex-1 disabled:opacity-40" onClick={()=>nav(`/checkout?buy=${p.id}`)}>Buy Now</button><button disabled={!p.available} className="btn btn-g flex-1 disabled:opacity-40" onClick={()=>{addToCart(p.id);nav('/cart')}}>Add to Cart</button></div>
      {p.demo&&<a href={p.demo} target="_blank" className="btn btn-g w-full">Live Demo ↗</a>}
      <dl className="text-sm grid grid-cols-3 gap-y-2 border-t border-white/10 pt-4 text-white/60"><dt>Status</dt><dd className="col-span-2">{p.available?'Available':'Unavailable'}</dd><dt>Version</dt><dd className="col-span-2">{p.version}</dd><dt>Tech</dt><dd className="col-span-2">{p.tech.join(', ')}</dd><dt>License</dt><dd className="col-span-2">{p.license}</dd><dt>Needs</dt><dd className="col-span-2">{p.requirements}</dd></dl>
    </div></aside></div>
}
