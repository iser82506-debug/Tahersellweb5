import {useState} from 'react'
import {Link,useNavigate} from 'react-router-dom'
import {useStore} from '../lib/store'
// MOCK auth. Admin demo login: admin@taher.dev / admin123
function Form({reg}:{reg?:boolean}){
  const {setUser,setAdmin}=useStore();const nav=useNavigate();const [f,setF]=useState({name:'',email:'',password:''})
  const go=(e:any)=>{e.preventDefault();if(!reg&&f.email==='admin@taher.dev'&&f.password==='admin123'){setAdmin(true);setUser({name:'Admin',email:f.email});return nav('/admin')}
    setUser({name:f.name||f.email.split('@')[0],email:f.email});nav('/account')}
  return <form onSubmit={go} className="glass max-w-md mx-auto my-16 p-8 space-y-4"><h1 className="h1 text-3xl">{reg?'Create account':'Welcome back'}</h1>
    {reg&&<input required className="input" placeholder="Name" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/>}
    <input required type="email" className="input" placeholder="Email" value={f.email} onChange={e=>setF({...f,email:e.target.value})}/><input required type="password" className="input" placeholder="Password" value={f.password} onChange={e=>setF({...f,password:e.target.value})}/>
    <button className="btn btn-p w-full">{reg?'Register':'Login'}</button><p className="text-sm text-white/50 text-center">{reg?<Link to="/login">Have an account? Login</Link>:<Link to="/register">New here? Register</Link>}</p></form>
}
export const Login=()=><Form/>
export const Register=()=><Form reg/>
