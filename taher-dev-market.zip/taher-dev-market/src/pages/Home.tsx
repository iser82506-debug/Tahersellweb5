import {Link} from 'react-router-dom'
import {useStore} from '../lib/store'
import ProductCard from '../components/ProductCard'
import {reviews} from '../lib/data'
const Head=({t,s,to}:{t:string;s?:string;to?:string})=><div className="flex items-end justify-between mb-8"><div><h2 className="h1 text-3xl md:text-4xl">{t}</h2>{s&&<p className="text-white/50 mt-2">{s}</p>}</div>{to&&<Link to={to} className="text-sm text-violet-300">View all →</Link>}</div>
export default function Home(){
  const {products,categories}=useStore()
  const latest=[...products].sort((a:any,b:any)=>b.createdAt-a.createdAt).slice(0,4)
  const tools=products.filter((p:any)=>p.category==='Developer Tools')
  return <div>
    <section className="max-w-6xl mx-auto px-4 pt-20 md:pt-32 pb-20 text-center">
      <span className="glass px-4 py-1.5 text-xs text-gold inline-block !rounded-full">Premium digital products by Developer Taher</span>
      <h1 className="h1 text-5xl md:text-8xl mt-6">Build Faster.<br/><span className="grad">Launch Smarter.</span></h1>
      <p className="max-w-xl mx-auto mt-6 text-white/60 text-lg">Premium websites, source code, developer tools and digital products built by Developer Taher.</p>
      <div className="flex flex-wrap gap-3 justify-center mt-10"><Link to="/products" className="btn btn-p">Explore Products</Link><Link to="/categories" className="btn btn-g">View Categories</Link></div>
    </section>
    <div className="max-w-6xl mx-auto px-4 space-y-24">
      <section><Head t="Featured Products" s="Hand-picked best sellers" to="/products"/><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">{products.filter((p:any)=>p.featured).slice(0,4).map((p:any)=><ProductCard key={p.id} p={p}/>)}</div></section>
      <section><Head t="Latest Products" to="/products"/><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">{latest.map((p:any)=><ProductCard key={p.id} p={p}/>)}</div></section>
      <section><Head t="Categories"/><div className="grid grid-cols-2 md:grid-cols-3 gap-4">{categories.map((c:string)=><Link key={c} to={`/products?cat=${encodeURIComponent(c)}`} className="glass lift p-6 font-semibold">{c}<div className="text-xs text-white/40 mt-1">{products.filter((p:any)=>p.category===c).length} products →</div></Link>)}</div></section>
      {tools.length>0&&<section><Head t="Developer Tools" s="Utilities that fit your workflow"/><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">{tools.slice(0,4).map((p:any)=><ProductCard key={p.id} p={p}/>)}</div></section>}
      <section><Head t="Why TAHER DEV MARKET"/><div className="grid md:grid-cols-4 gap-4">{[['⚡','Production-ready','Clean, typed, documented code.'],['🔑','Instant access','Download and license key right after purchase.'],['🛠','Easy to customize','Built to extend, not fight.'],['🔄','Free updates','Improvements shipped to you.']].map(([i,t,d])=><div key={t} className="glass p-6"><div className="text-2xl">{i}</div><b className="block mt-3">{t}</b><p className="text-sm text-white/50 mt-1">{d}</p></div>)}</div></section>
      <section><Head t="Customer Reviews"/><div className="grid md:grid-cols-3 gap-5">{reviews.map(([n,r,t])=><div key={n} className="glass p-6"><div className="text-gold">★★★★★</div><p className="mt-3 text-white/75">“{t}”</p><div className="mt-4 text-sm"><b>{n}</b> <span className="text-white/40">· {r}</span></div></div>)}</div></section>
      <section className="glass p-10 md:p-16 text-center"><h2 className="h1 text-4xl md:text-5xl">Ready to <span className="grad">launch</span>?</h2><p className="text-white/55 mt-4">Pick a product and ship your next project today.</p><Link to="/products" className="btn btn-p mt-8">Browse the Market</Link></section>
    </div></div>
}
