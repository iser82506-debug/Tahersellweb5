import {Link} from 'react-router-dom'
import {Product} from '../types'
import {effective,taka} from '../utils/format'
import {useStore} from '../lib/store'
export function Cover({p,className=''}:{p:Product;className?:string}){
  if(p.images[0])return <img src={p.images[0]} alt={p.name} className={`object-cover ${className}`}/>
  const h=[...p.id+p.name].reduce((a,c)=>a+c.charCodeAt(0),0)%360
  return <div className={`grid place-items-center ${className}`} style={{background:`linear-gradient(135deg,hsl(${h} 70% 45%),hsl(${(h+70)%360} 65% 18%))`}}><span className="h1 text-5xl text-white/30">{'</>'}</span></div>
}
export function Price({p}:{p:Product}){const e=effective(p);return <span className="flex items-baseline gap-2"><b className="text-gold text-lg">{taka(e)}</b>{e<p.price&&<s className="text-white/40 text-sm">{taka(p.price)}</s>}</span>}
export default function ProductCard({p}:{p:Product}){
  const {addToCart}=useStore()
  return <div className="glass lift overflow-hidden flex flex-col group">
    <Link to={`/products/${p.id}`} className="block overflow-hidden"><Cover p={p} className="h-44 w-full group-hover:scale-105 transition duration-500"/></Link>
    <div className="p-5 flex flex-col gap-2 flex-1">
      <div className="flex justify-between text-xs"><span className="text-violet-300">{p.category}</span>{p.featured&&<span className="text-gold">★ Featured</span>}</div>
      <Link to={`/products/${p.id}`} className="font-semibold text-lg leading-tight">{p.name}</Link>
      <p className="text-sm text-white/55 flex-1">{p.short}</p>
      <div className="flex items-center justify-between pt-2"><Price p={p}/><button disabled={!p.available} onClick={()=>addToCart(p.id)} className="btn btn-g !py-2 disabled:opacity-40">{p.available?'Add':'Sold out'}</button></div>
    </div></div>
}
