import {useState} from 'react'
import {Link,NavLink,Outlet,useLocation} from 'react-router-dom'
import {useStore} from '../lib/store'
export default function MainLayout(){
  const {cart,user}=useStore();const {pathname}=useLocation();const [open,setOpen]=useState(false)
  const nl=({isActive}:any)=>`px-3 py-2 rounded-lg text-sm transition ${isActive?'text-white bg-white/10':'text-white/60 hover:text-white'}`
  return <div className="min-h-screen flex flex-col">
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#07070d]/70 backdrop-blur-xl"><div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
      <Link to="/" className="h1 text-lg tracking-tight">TAHER <span className="grad">DEV MARKET</span></Link>
      <nav className={`${open?'flex':'hidden'} md:flex absolute md:static top-16 left-0 right-0 flex-col md:flex-row gap-1 p-4 md:p-0 bg-[#07070d] md:bg-transparent border-b border-white/10 md:border-0`} onClick={()=>setOpen(false)}>
        <NavLink to="/products" className={nl}>Products</NavLink><NavLink to="/categories" className={nl}>Categories</NavLink>
        <NavLink to="/cart" className={nl}>Cart{cart.length>0&&<b className="ml-1.5 text-xs bg-violet-500 rounded-full px-1.5 py-0.5">{cart.length}</b>}</NavLink>
        {user?<NavLink to="/account" className={nl}>{user.name}</NavLink>:<NavLink to="/login" className={nl}>Login</NavLink>}
      </nav>
      <button className="md:hidden btn btn-g !px-3" onClick={()=>setOpen(!open)}>☰</button></div></header>
    <main key={pathname} className="page flex-1"><Outlet/></main>
    <footer className="border-t border-white/10 mt-24"><div className="max-w-6xl mx-auto px-4 py-10 flex flex-wrap justify-between gap-6 text-sm text-white/50">
      <div><div className="h1 text-white text-lg">TAHER DEV MARKET</div><p className="mt-1">Build Faster. Launch Smarter.</p></div>
      <div className="flex gap-6"><Link to="/products">Products</Link><Link to="/categories">Categories</Link><Link to="/account">Account</Link><Link to="/admin">Admin</Link></div>
      <p>© {new Date().getFullYear()} Developer Taher</p></div></footer></div>
}
