import {Product} from '../types'
export const effective=(p:Product)=>p.salePrice&&p.salePrice<p.price?p.salePrice:p.price
export const taka=(n:number)=>'৳'+n.toLocaleString('en-US')
export const date=(t:number)=>new Date(t).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})
const seg=()=>Math.random().toString(36).slice(2,6).toUpperCase()
export const licenseKey=()=>`TDM-${seg()}-${seg()}-${seg()}`
export const orderId=()=>'TDM-'+Date.now().toString(36).toUpperCase()
export const list=(s:string)=>s.split(/[,\n]/).map(x=>x.trim()).filter(Boolean)
export function download(name:string,key:string){const b=new Blob([`Thank you for purchasing ${name}\nLicense key: ${key}\n\n(Mock download — connect your real file URL in the product's downloadUrl.)`],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name.replace(/\s+/g,'-').toLowerCase()+'.txt';a.click()}
