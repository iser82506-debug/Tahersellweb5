export type Product={id:string;name:string;short:string;description:string;images:string[];demo:string;category:string;tech:string[];features:string[];version:string;included:string[];requirements:string;license:string;price:number;salePrice?:number;available:boolean;featured:boolean;createdAt:number;downloadUrl:string}
export type OrderStatus='pending'|'completed'|'refunded'
export type Order={id:string;email:string;name:string;items:{id:string;name:string;price:number;licenseKey:string}[];total:number;status:OrderStatus;payment:'paid'|'pending'|'failed';method:string;createdAt:number}
export type User={name:string;email:string}
