// MOCK gateway. Replace the body with a real gateway (bKash, SSLCommerz, Stripe...) later.
export async function pay(amount:number,method:string):Promise<{ok:boolean;ref:string}>{
  await new Promise(r=>setTimeout(r,1200));return{ok:true,ref:'MOCK-'+Date.now()}}
