import {Product} from '../types'
export const seedCategories=['Websites','Source Code','Developer Tools','Scripts','UI Kits','License Keys']
// Prices below are PLACEHOLDERS — change them anytime in /admin.
const mk=(n:number,name:string,category:string,tech:string[],price:number,salePrice?:number,featured=false):Product=>({id:'p'+n,name,short:`${name} — production-ready and fully documented.`,description:`${name} by Developer Taher. Clean, well-structured and ready to customize and ship. Includes documentation and updates for the listed version.`,images:[],demo:'https://example.com',category,tech,features:['Clean, documented code','Fully responsive','Easy to customize','Free updates'],version:'1.0.0',included:['Source files','Documentation','License file'],requirements:'Node.js 18+ and a modern browser',license:'Single project license',price,salePrice,available:true,featured,createdAt:Date.now()-n*864e5,downloadUrl:'#'})
export const seedProducts:Product[]=[
mk(1,'Nova SaaS Landing','Websites',['React','Tailwind'],2500,1900,true),
mk(2,'Aurora Portfolio','Websites',['Next.js','Tailwind'],1800),
mk(3,'Fullstack Auth Starter','Source Code',['React','Supabase'],3200,undefined,true),
mk(4,'Admin Panel Pro','Source Code',['React','TypeScript'],4000,3400,true),
mk(5,'API Forge CLI','Developer Tools',['Node.js'],1500),
mk(6,'Env Guard','Developer Tools',['TypeScript'],900),
mk(7,'Auto Deploy Scripts','Scripts',['Bash','Python'],700),
mk(8,'Glass UI Kit','UI Kits',['Figma','React'],2200,1800,true),
mk(9,'Pro Toolkit License','License Keys',['Desktop'],1200)]
export const reviews=[['Rafi A.','Frontend Dev','The code quality is exceptional. Saved me a week of work.'],['Nusrat J.','Freelancer','Delivered a client site in two days using the landing template.'],['Imran H.','Startup Founder','Clean, modern and easy to extend. Worth every taka.']]
