import {createContext,useContext,useEffect,useState,ReactNode} from 'react'
import {Product,Order,User,OrderStatus} from '../types'
import {seedProducts,seedCategories} from './data'
const KEY='tdm:v1'
const saved=(()=>{try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch{return null}})()
const Ctx=createContext<any>(null)
export const useStore=()=>useContext(Ctx)
export function StoreProvider({children}:{children:ReactNode}){
  const [products,setProducts]=useState<Product[]>(saved?.products??seedProducts)
  const [categories,setCategories]=useState<string[]>(saved?.categories??seedCategories)
  const [cart,setCart]=useState<string[]>(saved?.cart??[])
  const [orders,setOrders]=useState<Order[]>(saved?.orders??[])
  const [user,setUser]=useState<User|null>(saved?.user??null)
  const [admin,setAdmin]=useState<boolean>(saved?.admin??false)
  useEffect(()=>{localStorage.setItem(KEY,JSON.stringify({products,categories,cart,orders,user,admin}))},[products,categories,cart,orders,user,admin])
  const api={products,categories,setCategories,cart,orders,user,admin,setAdmin,setUser,
    addToCart:(id:string)=>setCart(c=>c.includes(id)?c:[...c,id]),
    removeFromCart:(id:string)=>setCart(c=>c.filter(x=>x!==id)),
    clearCart:()=>setCart([]),
    logout:()=>{setUser(null);setAdmin(false)},
    saveProduct:(p:Product)=>setProducts(l=>l.some(x=>x.id===p.id)?l.map(x=>x.id===p.id?p:x):[p,...l]),
    deleteProduct:(id:string)=>setProducts(l=>l.filter(x=>x.id!==id)),
    addOrder:(o:Order)=>setOrders(l=>[o,...l]),
    updateOrder:(id:string,status:OrderStatus)=>setOrders(l=>l.map(o=>o.id===id?{...o,status}:o))}
  return <Ctx.Provider value={api}>{children}</Ctx.Provider>
}
