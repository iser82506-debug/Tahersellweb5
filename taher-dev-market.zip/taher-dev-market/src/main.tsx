import React from 'react'
import {createRoot} from 'react-dom/client'
import {HashRouter,Routes,Route} from 'react-router-dom'
import './index.css'
import {StoreProvider} from './lib/store'
import MainLayout from './layouts/MainLayout'
import Home from './pages/Home'
import {Products,Categories,ProductDetails} from './pages/Shop'
import {Cart,Checkout,OrderPage} from './pages/Orders'
import {Login,Register} from './pages/Auth'
import {Account,MyOrders} from './pages/Account'
import Admin from './pages/Admin'
createRoot(document.getElementById('root')!).render(<StoreProvider><HashRouter><Routes><Route element={<MainLayout/>}>
<Route index element={<Home/>}/><Route path="products" element={<Products/>}/><Route path="products/:id" element={<ProductDetails/>}/><Route path="categories" element={<Categories/>}/>
<Route path="cart" element={<Cart/>}/><Route path="checkout" element={<Checkout/>}/><Route path="order/:id" element={<OrderPage/>}/>
<Route path="login" element={<Login/>}/><Route path="register" element={<Register/>}/><Route path="account" element={<Account/>}/><Route path="account/orders" element={<MyOrders/>}/><Route path="admin" element={<Admin/>}/>
</Route></Routes></HashRouter></StoreProvider>)
